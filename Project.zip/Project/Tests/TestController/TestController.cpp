#include "TestController.h"
#include "TestUserController/TestUserController.h"
#include "TestElectricScooterController/TestElectricScooterController.h"

void testController() {
    testUserController();
    testElectricScooterController();
}