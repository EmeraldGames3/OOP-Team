#pragma once

void testDomain();