#include "TestDomain.h"
#include "TestDate/TestDate.h"
#include "TestUser/TestUser.h"

void testDomain() {
    testDate();
    testUser();
};