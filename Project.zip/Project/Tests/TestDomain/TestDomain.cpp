#include "TestDomain.h"
#include "TestDate/TestDate.h"
#include "TestUser/TestUser.h"
#include "TestElectricScooter/TestElectricScooter.h"

void testDomain() {
    testDate();
    testUser();
    testElectricScooter();
}