#include "Manager.h"

using namespace Domain;

///Constructor
Manager::Manager(const string &username, const string &password) : User(username, password) {}