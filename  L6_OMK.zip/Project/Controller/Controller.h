#pragma once

#include "ElectricScooterController/ElectricScooterController.h"
#include "UserController/UserController.h"

namespace Controller {
    class ElectricScooterController;
    class UserController;
}