#pragma once

void testElectricScooter();