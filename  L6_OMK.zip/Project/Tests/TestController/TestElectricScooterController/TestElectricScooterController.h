#pragma once

void testElectricScooterController();